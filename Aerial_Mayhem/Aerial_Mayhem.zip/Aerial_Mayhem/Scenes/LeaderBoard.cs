﻿using Aerial_Mayhem.DrawUtils;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Aerial_Mayhem.Scenes
{
    class LeaderBoard:GameScene
    {
        Button back;
         public LeaderBoard(ContentManager Content, GraphicsDeviceManager g)
        {
            bgd = new Background(Content, 0, 0, "Fondo_LeaderBoards");
        }
        public override void Update(GameTime gameTime)
        {

        }

        public override void Draw(SpriteBatch sp)
        {

        }
    }
}
