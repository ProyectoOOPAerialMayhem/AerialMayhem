﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Aerial_Mayhem

{
    enum GameScenes
    {
        StartScreen, OptionScreen, CharacterSlector, LevelSelector, Pause, GameOver,Level1,Level2,Level3,LeaderBoard
    }
}
